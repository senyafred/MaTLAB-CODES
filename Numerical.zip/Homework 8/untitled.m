theta = linspace(0,2*pi,100);
r=2;
x0 = 1.5;
y0=0.5;

x=r*cos(theta)*x0;
y=r*sin(theta)*y0;

plot(x,y)

